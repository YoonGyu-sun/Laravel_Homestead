CKEDITOR.editorConfig = function (config) {
    config.height = '300px'; // 원하는 높이 값으로 변경
};