<div class="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8 flex justify-between items-center">
    <div class="text-lg">작성글 수 <small class="text-neutral-500"> : <?php echo e($count); ?></small> </div>
        
    <div>
        <a href="<?php echo e(route('managements.create')); ?>"><?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php echo e(__('글쓰기')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?></a>
    </div>
</div>
 <div class="grid place-items-center w-full">   
    <div class="bg-white w-8/12 p-5 flex border border-gray-300 items-center mb-4">
        <div class="text-sm">
            <input type="checkbox" name="all_chk" value="1" class="w-3 h-3">  전체선택
        </div>
        
        
       
        <div class="flex items-center ml-auto relative">
            <button type="button" onclick="toggleOptions()" class="flex items-center space-x-1 py-2 px-4 rounded-md shadow-md hover:bg-gray-200">
                <span class="text-sm">구분</span>
                <svg class="w-4 h-4 text-black" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 9l-7 7-7-7" />
                </svg>
            </button>



            <div class="ml-2">
                <form actioon="<?php echo e(route('managements.index')); ?>" action="GET"> 
                    <input class="w-full focus:outline-none text-xs" type="text" placeholder="검색" id="q" name="q">
                    <button type="submit" class="border border-gray-500">전송</button>
                </form>

            </div>
        </div>
        
        
        <div id="options" class="hidden absolute right-1/4 top-56 bg-white  shadow-md"> 
             <ul>
                 <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="hover:bg-gray-100 cursor-pointer  px-24 py-1 text-sm" onclick="category_button()"> <?php echo e($category->cat_name); ?></li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>    
        </div>
    </div>
    
        <script>
            // 구분에 대한 JS
            function toggleOptions() {
                var options = document.getElementById("options");
                options.classList.toggle("hidden");
            }

            // 구분 list Onclick시 동적 페이지 전환
            function category_button(){
                window.location.href="<?php echo e(route('tasks.index')); ?>";
            }
        </script>
        

    <?php $__currentLoopData = $managements->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($management->user->is(auth()->user())): ?>
            <div class="bg-white w-8/12 border border-gray-300 items-center flex p-6">
                    <div>
                        <input type="checkbox" name="all_chk" value="1" class="w-3 h-3">
                    </div>
                    
                    <div class="ml-4">
                        <?php echo e($management->type); ?>

                    </div>
                    
                    <div class="ml-4">
                        <?php echo e($management->title); ?>

                    </div>
                
                    
                    <div class = "ml-auto flex">
                        <button class="border border-slate-90 p-1 rounded mr-2" onclick="window.location.href = '<?php echo e(route('managements.edit', $management)); ?>'"><?php echo e(__('수정')); ?></button>
                        

                    <form action="<?php echo e(route('managements.destroy', $management)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="border border-slate-90 p-1 rounded" onclick="return confirm('삭제하시겠습니까?')" window.location.href = '<?php echo e(route('managements.destroy', $management)); ?>'><?php echo e(__('삭제')); ?></button>
                        </form>
                    </div>                    
            </div>
        <?php endif; ?>      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>    <?php /**PATH /home/vagrant/project/website/resources/views/managements/main.blade.php ENDPATH**/ ?>