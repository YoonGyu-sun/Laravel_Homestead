

    
    <?php $__env->startSection('session_name'); ?>
            <?php echo e($management->user->name); ?>

    <?php $__env->stopSection(); ?>

    
    <?php $__env->startSection('type'); ?>
        <div>
            <?php echo e(old('type',$management->type)); ?>

        <div>
    <?php $__env->stopSection(); ?>

    
    <?php $__env->startSection('title1'); ?>
        <div>
            <?php echo e(old('title',$management->title)); ?>

        </div>
    <?php $__env->stopSection(); ?>

    
    <?php $__env->startSection('qq'); ?>
        <div>
            <?php echo e(strip_tags(old('body',$management->body))); ?>

        <div>    

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('showlayouts.showlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/project/website/resources/views/managements/show.blade.php ENDPATH**/ ?>