<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8 flex justify-between items-center">
        <div class="text-lg">작성글 수 <small class="text-neutral-500"> : <?php echo e($count); ?></small> </div>
            
        <div>
            <a href="<?php echo e(route('managements.create')); ?>"><?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php echo e(__('글쓰기')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?></a>
        </div>
    </div>

        <div class="grid place-items-center w-full">   
            <div class="bg-white w-8/12 p-5 flex border border-gray-300 items-center mb-4">
                <div class="text-sm">
                    <input type="checkbox" name="all_chk" value="1" class="w-3 h-3">  전체선택
                </div>
            
                                    
                        <div class="flex items-center ml-auto relative">
                                <form action="<?php echo e(route('managements.index')); ?>" method="GET" id="categoryForm">
                                    <select id="categorySelect"  name="p" onchange="category_button()">
                                        <option value="" disabled selected class>구분</option>
                                        
                                        <!-- 선택할 수 있는 옵션 목록을 생성합니다. -->
                                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($category->user->is(auth()->user())): ?>
                                                <option value="<?php echo e($category->cat_name); ?>"><?php echo e($category->cat_name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                    
                                </form>
                        </div>
                        <script>
                            function category_button(){
                                document.getElementById("categoryForm").submit();            
                            }
                        </script>
                
                    
                    <div class="ml-2">
                        <form action="<?php echo e(route('managements.index')); ?>" method="GET"> 
                            <input class="w-full focus:outline-none text-xs" type="text" placeholder="검색" name="q">
                            <button type="submit" class="border border-gray-500">전송</button>
                        </form>
                    
                    </div>
                    
            </div>
        
            
            
        
                <?php $__currentLoopData = $managements->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($management->user->is(auth()->user())): ?>
                        <div class="bg-white w-8/12 border border-gray-300 items-center flex p-6" onmouseenter="showButtons(this)" onmouseleave="hideButtons(this)">
                                <div>
                                    <input type="checkbox" name="all_chk" value="1" class="w-3 h-3">
                                </div>

                                <div class="ml-4 font-bold" onmouseenter="titleUnder(this)" onmouseleave="titleNone(this)">
                                    <a href="<?php echo e(route('managements.show', $management)); ?>"> 
                                     <?php echo e($management->title); ?>

                                    </a>
                                </div>
                                
                                <div class = "ml-auto flex">
                                    <button class="border border-gray-400 p-1 rounded mr-2 hidden" onclick="window.location.href = '<?php echo e(route('managements.edit', $management)); ?>'"><?php echo e(__('수정')); ?></button>

                                
                                <form action="<?php echo e(route('managements.destroy', $management)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="border border-gray-400 p-1 rounded hidden" onclick="return confirm('삭제하시겠습니까?')" window.location.href = '<?php echo e(route('managements.destroy', $management)); ?>'><?php echo e(__('삭제')); ?></button>
                                    </form>
                                </div>                    
                        </div>
                    <?php endif; ?>      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <script>
                    function showButtons(element) {
                        element.classList.remove("bg-white");
                        element.classList.add("bg-gray-200");
                        
                        const buttons = element.querySelectorAll("button");
                        buttons.forEach((button) => {
                            button.classList.remove("hidden");
                        });
                    }

                    function hideButtons(element) {
                        element.classList.remove("bg-gray-200");
                        element.classList.add("bg-white");
                        
                        const buttons = element.querySelectorAll("button");
                        buttons.forEach((button) => {
                            button.classList.add("hidden");
                        });
                    }

                    function titleUnder(element){
                        const hrefs = element.querySelectorAll("a");
                        hrefs.forEach((a)=> {
                            a.classList.add("underline");
                        });
                    }

                    function titleNone(element){
                        const hrefs = element.querySelectorAll("a");
                        hrefs.forEach((a)=> {
                            a.classList.remove("underline");
                        });
                    }

                    
                </script>

                
        </div>    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH /home/vagrant/project/website/resources/views/managements/index.blade.php ENDPATH**/ ?>