<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-60 py-6">
        <div class="text-lg">
            카테고리 관리
        </div>
    
        <div class="pl-6 pt-4">
            <div class="border border-black h-auto h=3/4 w-3/5 p-1 px-2 bg-slate-200">
                <ul>
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->user->is(auth()->user())): ?>
                            <div class="border border-gray-500 p-2 flex items-center justify-between my-1 bg-gray-100">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zM3.75 12h.007v.008H3.75V12zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm-.375 5.25h.007v.008H3.75v-.008zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                                </svg>
                                <li class="pt-1 my-1 ml-2">
                                <?php if(strlen($category->cat_name) > 50): ?>
                                    <?php echo e(mb_substr($category->cat_name, 0,30)); ?> ···
                                <?php else: ?>
                                    <?php echo e($category->cat_name); ?>

                                <?php endif; ?>&nbsp;&nbsp;<small><?php echo e(__('count 수')); ?></small></li>
                                <button id="modal-open-btn-update" type="button" class="text-sm ml-auto mr-2 border border-gray-400 py-1 px-2 rounded hover:bg-gray-200" data-cat-id="<?php echo e($category->id); ?>" data-cat-name="<?php echo e($category->cat_name); ?>">수정</button>
                                
                                <form action="<?php echo e(route('categorys.destroy', $category)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="text-sm ml-1 mr-2 border border-gray-400 py-1 px-2 rounded hover:bg-gray-200" onclick="return confirm('삭제하시겠습니까?')" window.location.href = '<?php echo e(route('categorys.destroy', $category)); ?>'><?php echo e(__('삭제')); ?></button>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    

    <br><br><br><br><br><br>


    
        <div>
            <button id="modal-open-btn" class="flex items-center space-x-1 pl-5 absolute">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 16.875h3.375m0 0h3.375m-3.375 0V13.5m0 3.375v3.375M6 10.5h2.25a2.25 2.25 0 002.25-2.25V6a2.25 2.25 0 00-2.25-2.25H6A2.25 2.25 0 003.75 6v2.25A2.25 2.25 0 006 10.5zm0 9.75h2.25A2.25 2.25 0 0010.5 18v-2.25a2.25 2.25 0 00-2.25-2.25H6a2.25 2.25 0 00-2.25 2.25V18A2.25 2.25 0 006 20.25zm9.75-9.75H18a2.25 2.25 0 002.25-2.25V6A2.25 2.25 0 0018 3.75h-2.25A2.25 2.25 0 0013.5 6v2.25a2.25 2.25 0 002.25 2.25z" />
                </svg>
                <span class="font-semibold">카테고리 추가</span>
            </button>  
        </div>
    

        <br><br><br><br><br><br>

    
        <div class="modal-wrapper hidden fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
            <div class="modal-body bg-white w-500 h-500">
                <div class="modal-head flex items-center ">
                    <h3 class="mb-2 pt-2 px-3">카테리고 추가.</h3>

                    <button id="modal-close-btn1" class="ml-auto pr-3">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>


                
                <div class="modal-content bg-gray-100 py-10 px-6">
                    <form method="POST" action="<?php echo e(route('categorys.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label>카테고리 :</label>
                            <input type="text" name="cat_name" id="cat_name" placeholder="<?php echo e(__('카테고리란')); ?>" class="border border-gray-300 rounded-lg px-4 py-2 mb-2 <?php $__errorArgs = ['cat_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-700 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('cat_name') ? old('cat_name'):''); ?>">

                        </div>
                        <div class="flex justify-end space-x-4">
                            <input type="submit" class="hover:cursor-pointer w-12 h-8 rounded-lg border border-gray-300 bg-gray-200 hover:bg-gray-300" value="저장">
                            <button id="modal-close-btn2" class="w-12 h-8 rounded-lg border border-gray-300 bg-gray-200 hover:bg-gray-300">닫기</button>
                        </div>
                    </form>    
                </div>
            </div>        
        </div>
    


    
    
    <div class="modal-wrapper-update hidden fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
        <div class="modal-body bg-white w-500 h-500">
            <div class="modal-head flex items-center ">
                <h3 class="mb-2 pt-2 px-3">카테리고 변경.</h3>
            
                <button id="modal-close-btn1-update" class="ml-auto pr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        
        
            
            <div class="modal-content bg-gray-100 py-10 px-6">
                <form method="POST" action="<?php echo e(route('categorys.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label>카테고리 :</label>
                        <input type="text" name="cat_name" id="cat_name" placeholder="<?php echo e(__('카테고리 변경')); ?>" class="border border-gray-300 rounded-lg px-4 py-2 mb-2 <?php $__errorArgs = ['cat_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-700 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('cat_name') ? old('cat_name'):''); ?>">
                    
                    </div>
                    <div class="flex justify-end space-x-4">
                        <input type="submit" class="hover:cursor-pointer w-12 h-8 rounded-lg border border-gray-300 bg-gray-200 hover:bg-gray-300" value="저장">
                        <button id="modal-close-btn2-update" class="w-12 h-8 rounded-lg border border-gray-300 bg-gray-200 hover:bg-gray-300">닫기</button>
                    </div>
                </form>    
            </div>
        </div>        
    </div>
    
    


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            // 모달 카테고리 추가 (popup 창)
            const modalOpenBtn = document.getElementById("modal-open-btn");
            const modalCloseBtn1 = document.getElementById("modal-close-btn1");
            const modalCloseBtn2 = document.getElementById("modal-close-btn2");
            const modalWrapper = document.querySelector(".modal-wrapper");

            console.log(modalWrapper.style);

            modalOpenBtn.addEventListener("click", () => {
                modalWrapper.classList.remove("hidden");
            });

            modalCloseBtn1.addEventListener("click", () => {
                modalWrapper.classList.add("hidden");
            });

            modalCloseBtn2.addEventListener("click", () => {
                modalWrapper.classList.add("hidden");
            });




             // 모달 카테고리 수정 (popup 창)
            const modalOpenBtn_update = document.getElementById("modal-open-btn-update");
            const modalCloseBtn1_update = document.getElementById("modal-close-btn1-update");
            const modalCloseBtn2_update = document.getElementById("modal-close-btn2-update");
            const modalWrapper_update = document.querySelector(".modal-wrapper-update");

            console.log(modalWrapper_update.style);

            modalOpenBtn_update.addEventListener("click", () => {
                modalWrapper_update.classList.remove("hidden");
            });

            modalCloseBtn1_update.addEventListener("click", () => {
                modalWrapper_update.classList.add("hidden");
            });

            modalCloseBtn2_update.addEventListener("click", () => {
                modalWrapper_update.classList.add("hidden");
            });



        </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/vagrant/project/website/resources/views/categorys/index.blade.php ENDPATH**/ ?>