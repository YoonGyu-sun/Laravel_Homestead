<div class="modal-wrapper-update hidden fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
    <div class="modal-body bg-white w-500 h-500">
        <div class="modal-head flex items-center">
            <h3 class="mb-2 pt-2 px-3">카테리고 변경.</h3>
            <button id="modal-close-btn1-update" class="ml-auto pr-3">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <div class="modal-content bg-gray-100 py-10 px-6">
            <form method="POST" action="<?php echo e(route('categorys.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <label>카테고리 :</label>
                    <input type="text" name="cat_name" id="cat_name" placeholder="<?php echo e(__('카테고리 변경')); ?>" class="border border-gray-300 rounded-lg px-4 py-2 mb-2 <?php $__errorArgs = ['cat_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-700 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('cat_name') ? old('cat_name'):''); ?>">
                </div>
                <div class="flex justify-end space-x-4">
                    <input type="submit" class="hover:cursor-pointer w-12 h-8 rounded-lg border border-gray-300 bg-gray-200 hover:bg-gray-300" value="저장">
                    <button id="modal-close-btn2-update" class="w-12 h-8 rounded-lg border border-gray-300 bg-gray-200 hover:bg-gray-300">닫기</button>
                </div>
            </form>    
        </div>
    </div>        
</div>
<?php /**PATH /home/vagrant/project/website/resources/views/categorys/modal-update.blade.php ENDPATH**/ ?>